from tokens import tok
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup
from aiogram.dispatcher.filters import Text
from requests import get

import logging

tok_tg = tok

logging.basicConfig(level=logging.INFO)

bot = Bot(token=tok_tg)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def send_start(message: types.Message):
    title = '[Analytic Company](https://analyticco.ru/)'
    txt = ('\n'
           f'Добро пожаловать в телеграм-бот компании {title}\n\n'
           'Пожалуйста, выберите соответствующий раздел!'
           )

    text = title + txt

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    but_info = 'О нас'
    but_geon = 'Адрес'
    but_serv = 'Услуги'
    but_cont = 'Контакты'

    markup.add(but_info, but_serv, but_geon, but_cont)

    await message.answer(text.format(message.from_user), disable_web_page_preview=True, reply_markup=markup,
                         parse_mode='Markdown')


@dp.message_handler(Text(equals='О нас'))
async def mes_info(message: types.Message):
    title = '[Analytic Company](https://analyticco.ru/)'
    txt = ('\n'
           '*О нас*\n\n'
           'Наша компания занимается техническими испытаниями, исследованиями, анализами, а так же сертификацией '
           'продукции во многих пищевых и агрокультурных промышленностях!\n\n'
           )

    text = title + txt

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    but_geon = 'Адрес'
    but_serv = 'Услуги'
    but_cont = 'Контакты'

    markup.add(but_serv, but_geon, but_cont)

    url = 'https://cognitivepaper.com/userfiles/16/608_0.webp'
    photo = get(url)

    await bot.send_photo(message.chat.id, caption=text, photo=photo.content, parse_mode='Markdown',
                         reply_markup=markup)


@dp.message_handler(Text(equals='Адрес'))
async def mes_adress(message: types.Message):
    title = '[Analytic Company](https://analyticco.ru/)'
    txt = ('\n'
           '*Адрес*\n\n'
           '20 мин от м. Тушинская\n'
           '15 мин от мцд Трикотажная\n'
           )

    lat = 55.829131
    lon = 37.410389

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    but_info = 'О нас'
    but_serv = 'Услуги'
    but_cont = 'Контакты'

    markup.add(but_info, but_serv, but_cont)

    await message.answer(title + txt, parse_mode='Markdown', disable_web_page_preview=True, reply_markup=markup)
    await bot.send_venue(chat_id=message.from_user.id, latitude=lat, longitude=lon, title='Analytic company',
                         address='Москва, Волоколамское шоссе, 89')


@dp.message_handler(Text(equals='Услуги'))
async def mes_copp(message: types.Message):
    title = '[Analytic Company](https://analyticco.ru/)'
    txt = ('\n'
           '*Услуги*\n\n'
           'АНАЛИЗЫ:\n'
           '~ Продуктов питания\n'
           '~ Алкогольной продукции\n'
           '~ БАД и Спец. питания\n'
           '~ Воды\n'
           '~ Почвы\n'
           )

    url = 'https://avatars.mds.yandex.net/get-altay/933207/2a00000161bf5cf9558ca21e16e3e671ab9d/h300'
    photo = get(url)

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    but_info = 'О нас'
    but_geon = 'Адрес'
    but_cont = 'Контакты'
    but_appn = 'Заявка'

    markup.add(but_info, but_geon, but_cont, but_appn)

    await bot.send_photo(message.chat.id, caption=title + txt, photo=photo.content, parse_mode='Markdown',
                         reply_markup=markup)


@dp.message_handler(Text(equals='Контакты'))
async def mes_cont(message: types.Message):
    title = '[Analytic Company](https://analyticco.ru/)'
    txt = ('\n'
           '*Контакты*\n\n'
           '📱 +7 (925) 209 99 67\n'
           '☎️ +7 (499) 309 59 91\n'
           '✉️ [Почта](consult@analyticco.ru)\n\n'
           '*Вы так же можете оставить заявку на услугу:*\n\n'
           'Внизу появилась соответствующая кнопка!'
           )

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    but_info = 'О нас'
    but_geon = 'Адрес'
    but_serv = 'Услуги'
    but_appn = 'Заявка'

    markup.add(but_info, but_serv, but_geon, but_appn)

    await message.answer(title + txt, disable_web_page_preview=True, parse_mode='Markdown', reply_markup=markup)


@dp.message_handler(Text(equals='Заявка'))
async def mes_forms(message: types.Message):
    title = '[Analytic Company](https://analyticco.ru/)'
    txt = ('\n'
           '*Заявка*\n\n'
           'Оформление заявки производится в Яндекс-формах!\n'
           'Мы же от Вас получим форму обращения и ответим в ближайшее время😊\n\n'
           )
    form = '👉 [Оформление заявки](https://forms.yandex.ru/cloud/626702c4c8cf4ae2e871ea4f/)'

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    but_info = 'О нас'
    but_geon = 'Адрес'
    but_serv = 'Услуги'
    but_appn = 'Заявка'

    markup.add(but_info, but_serv, but_geon, but_appn)

    await message.answer(title + txt + form, disable_web_page_preview=True, parse_mode='Markdown',
                         reply_markup=markup)


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
